﻿
namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Screen = new System.Windows.Forms.TextBox();
            this.NUM1 = new System.Windows.Forms.Button();
            this.NUM2 = new System.Windows.Forms.Button();
            this.NUM3 = new System.Windows.Forms.Button();
            this.NUM4 = new System.Windows.Forms.Button();
            this.NUM5 = new System.Windows.Forms.Button();
            this.NUM6 = new System.Windows.Forms.Button();
            this.NUM7 = new System.Windows.Forms.Button();
            this.NUM8 = new System.Windows.Forms.Button();
            this.NUM9 = new System.Windows.Forms.Button();
            this.NUM0 = new System.Windows.Forms.Button();
            this.DIVD = new System.Windows.Forms.Button();
            this.MULTI = new System.Windows.Forms.Button();
            this.SUB = new System.Windows.Forms.Button();
            this.ADD = new System.Windows.Forms.Button();
            this.MEMC = new System.Windows.Forms.Button();
            this.MEMADD = new System.Windows.Forms.Button();
            this.POW = new System.Windows.Forms.Button();
            this.EQ = new System.Windows.Forms.Button();
            this.MEMSUB = new System.Windows.Forms.Button();
            this.MEMREAD = new System.Windows.Forms.Button();
            this.SQRT = new System.Windows.Forms.Button();
            this.CL = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Screen
            // 
            this.Screen.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Screen.Location = new System.Drawing.Point(7, 11);
            this.Screen.Multiline = true;
            this.Screen.Name = "Screen";
            this.Screen.Size = new System.Drawing.Size(280, 70);
            this.Screen.TabIndex = 0;
            this.Screen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // NUM1
            // 
            this.NUM1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM1.FlatAppearance.BorderSize = 0;
            this.NUM1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.NUM1.Location = new System.Drawing.Point(7, 286);
            this.NUM1.Name = "NUM1";
            this.NUM1.Size = new System.Drawing.Size(56, 56);
            this.NUM1.TabIndex = 1;
            this.NUM1.Text = "1";
            this.NUM1.UseVisualStyleBackColor = false;
            this.NUM1.Click += new System.EventHandler(this.NUM1_Click);
            // 
            // NUM2
            // 
            this.NUM2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM2.FlatAppearance.BorderSize = 0;
            this.NUM2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.NUM2.Location = new System.Drawing.Point(63, 286);
            this.NUM2.Name = "NUM2";
            this.NUM2.Size = new System.Drawing.Size(56, 56);
            this.NUM2.TabIndex = 2;
            this.NUM2.Text = "2";
            this.NUM2.UseVisualStyleBackColor = false;
            this.NUM2.Click += new System.EventHandler(this.NUM2_Click);
            // 
            // NUM3
            // 
            this.NUM3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM3.FlatAppearance.BorderSize = 0;
            this.NUM3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.NUM3.Location = new System.Drawing.Point(119, 286);
            this.NUM3.Name = "NUM3";
            this.NUM3.Size = new System.Drawing.Size(56, 56);
            this.NUM3.TabIndex = 3;
            this.NUM3.Text = "3";
            this.NUM3.UseVisualStyleBackColor = false;
            this.NUM3.Click += new System.EventHandler(this.NUM3_Click);
            // 
            // NUM4
            // 
            this.NUM4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM4.FlatAppearance.BorderSize = 0;
            this.NUM4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.NUM4.Location = new System.Drawing.Point(7, 230);
            this.NUM4.Name = "NUM4";
            this.NUM4.Size = new System.Drawing.Size(56, 56);
            this.NUM4.TabIndex = 4;
            this.NUM4.Text = "4";
            this.NUM4.UseVisualStyleBackColor = false;
            this.NUM4.Click += new System.EventHandler(this.NUM4_Click);
            // 
            // NUM5
            // 
            this.NUM5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM5.FlatAppearance.BorderSize = 0;
            this.NUM5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.NUM5.Location = new System.Drawing.Point(63, 230);
            this.NUM5.Name = "NUM5";
            this.NUM5.Size = new System.Drawing.Size(56, 56);
            this.NUM5.TabIndex = 5;
            this.NUM5.Text = "5";
            this.NUM5.UseVisualStyleBackColor = false;
            this.NUM5.Click += new System.EventHandler(this.NUM5_Click);
            // 
            // NUM6
            // 
            this.NUM6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM6.FlatAppearance.BorderSize = 0;
            this.NUM6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.NUM6.Location = new System.Drawing.Point(119, 230);
            this.NUM6.Name = "NUM6";
            this.NUM6.Size = new System.Drawing.Size(56, 56);
            this.NUM6.TabIndex = 6;
            this.NUM6.Text = "6";
            this.NUM6.UseVisualStyleBackColor = false;
            this.NUM6.Click += new System.EventHandler(this.NUM6_Click);
            // 
            // NUM7
            // 
            this.NUM7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM7.FlatAppearance.BorderSize = 0;
            this.NUM7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NUM7.Location = new System.Drawing.Point(7, 174);
            this.NUM7.Name = "NUM7";
            this.NUM7.Size = new System.Drawing.Size(56, 56);
            this.NUM7.TabIndex = 7;
            this.NUM7.Text = "7";
            this.NUM7.UseVisualStyleBackColor = false;
            this.NUM7.Click += new System.EventHandler(this.NUM7_Click);
            // 
            // NUM8
            // 
            this.NUM8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM8.FlatAppearance.BorderSize = 0;
            this.NUM8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.NUM8.Location = new System.Drawing.Point(63, 174);
            this.NUM8.Name = "NUM8";
            this.NUM8.Size = new System.Drawing.Size(56, 56);
            this.NUM8.TabIndex = 8;
            this.NUM8.Text = "8";
            this.NUM8.UseVisualStyleBackColor = false;
            this.NUM8.Click += new System.EventHandler(this.NUM8_Click);
            // 
            // NUM9
            // 
            this.NUM9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM9.FlatAppearance.BorderSize = 0;
            this.NUM9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.NUM9.Location = new System.Drawing.Point(119, 174);
            this.NUM9.Name = "NUM9";
            this.NUM9.Size = new System.Drawing.Size(56, 56);
            this.NUM9.TabIndex = 9;
            this.NUM9.Text = "9";
            this.NUM9.UseVisualStyleBackColor = false;
            this.NUM9.Click += new System.EventHandler(this.NUM9_Click);
            // 
            // NUM0
            // 
            this.NUM0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NUM0.FlatAppearance.BorderSize = 0;
            this.NUM0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NUM0.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.NUM0.Location = new System.Drawing.Point(175, 174);
            this.NUM0.Name = "NUM0";
            this.NUM0.Size = new System.Drawing.Size(56, 56);
            this.NUM0.TabIndex = 10;
            this.NUM0.Text = "0";
            this.NUM0.UseVisualStyleBackColor = false;
            this.NUM0.Click += new System.EventHandler(this.NUM0_Click);
            // 
            // DIVD
            // 
            this.DIVD.BackColor = System.Drawing.Color.Gray;
            this.DIVD.FlatAppearance.BorderSize = 0;
            this.DIVD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DIVD.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.DIVD.Location = new System.Drawing.Point(175, 118);
            this.DIVD.Name = "DIVD";
            this.DIVD.Size = new System.Drawing.Size(56, 56);
            this.DIVD.TabIndex = 11;
            this.DIVD.Text = "/";
            this.DIVD.UseVisualStyleBackColor = false;
            this.DIVD.Click += new System.EventHandler(this.DIVD_Click);
            // 
            // MULTI
            // 
            this.MULTI.BackColor = System.Drawing.Color.Gray;
            this.MULTI.FlatAppearance.BorderSize = 0;
            this.MULTI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MULTI.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.MULTI.Location = new System.Drawing.Point(119, 118);
            this.MULTI.Name = "MULTI";
            this.MULTI.Size = new System.Drawing.Size(56, 56);
            this.MULTI.TabIndex = 12;
            this.MULTI.Text = "*";
            this.MULTI.UseVisualStyleBackColor = false;
            this.MULTI.Click += new System.EventHandler(this.MULTI_Click);
            // 
            // SUB
            // 
            this.SUB.BackColor = System.Drawing.Color.Gray;
            this.SUB.FlatAppearance.BorderSize = 0;
            this.SUB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SUB.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.SUB.Location = new System.Drawing.Point(63, 118);
            this.SUB.Name = "SUB";
            this.SUB.Size = new System.Drawing.Size(56, 56);
            this.SUB.TabIndex = 13;
            this.SUB.Text = "-";
            this.SUB.UseVisualStyleBackColor = false;
            this.SUB.Click += new System.EventHandler(this.SUB_Click);
            // 
            // ADD
            // 
            this.ADD.BackColor = System.Drawing.Color.Gray;
            this.ADD.FlatAppearance.BorderSize = 0;
            this.ADD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ADD.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.ADD.Location = new System.Drawing.Point(7, 118);
            this.ADD.Name = "ADD";
            this.ADD.Size = new System.Drawing.Size(56, 56);
            this.ADD.TabIndex = 14;
            this.ADD.Text = "+";
            this.ADD.UseVisualStyleBackColor = false;
            this.ADD.Click += new System.EventHandler(this.ADD_Click);
            // 
            // MEMC
            // 
            this.MEMC.BackColor = System.Drawing.Color.DarkGray;
            this.MEMC.FlatAppearance.BorderSize = 0;
            this.MEMC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MEMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.MEMC.Location = new System.Drawing.Point(7, 87);
            this.MEMC.Name = "MEMC";
            this.MEMC.Size = new System.Drawing.Size(56, 31);
            this.MEMC.TabIndex = 15;
            this.MEMC.Text = "MC";
            this.MEMC.UseVisualStyleBackColor = false;
            this.MEMC.Click += new System.EventHandler(this.MEMC_Click);
            // 
            // MEMADD
            // 
            this.MEMADD.BackColor = System.Drawing.Color.DarkGray;
            this.MEMADD.FlatAppearance.BorderSize = 0;
            this.MEMADD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MEMADD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.MEMADD.Location = new System.Drawing.Point(63, 87);
            this.MEMADD.Name = "MEMADD";
            this.MEMADD.Size = new System.Drawing.Size(56, 31);
            this.MEMADD.TabIndex = 16;
            this.MEMADD.Text = "M+";
            this.MEMADD.UseVisualStyleBackColor = false;
            this.MEMADD.Click += new System.EventHandler(this.MEMADD_Click);
            // 
            // POW
            // 
            this.POW.BackColor = System.Drawing.Color.Gray;
            this.POW.FlatAppearance.BorderSize = 0;
            this.POW.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.POW.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.POW.Location = new System.Drawing.Point(231, 118);
            this.POW.Name = "POW";
            this.POW.Size = new System.Drawing.Size(56, 56);
            this.POW.TabIndex = 17;
            this.POW.Text = "x^y";
            this.POW.UseVisualStyleBackColor = false;
            this.POW.Click += new System.EventHandler(this.POW_Click);
            // 
            // EQ
            // 
            this.EQ.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.EQ.FlatAppearance.BorderSize = 0;
            this.EQ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.EQ.Location = new System.Drawing.Point(175, 230);
            this.EQ.Name = "EQ";
            this.EQ.Size = new System.Drawing.Size(56, 112);
            this.EQ.TabIndex = 18;
            this.EQ.Text = "=";
            this.EQ.UseVisualStyleBackColor = false;
            this.EQ.Click += new System.EventHandler(this.EQ_Click);
            // 
            // MEMSUB
            // 
            this.MEMSUB.BackColor = System.Drawing.Color.DarkGray;
            this.MEMSUB.FlatAppearance.BorderSize = 0;
            this.MEMSUB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MEMSUB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.MEMSUB.Location = new System.Drawing.Point(119, 87);
            this.MEMSUB.Name = "MEMSUB";
            this.MEMSUB.Size = new System.Drawing.Size(56, 31);
            this.MEMSUB.TabIndex = 19;
            this.MEMSUB.Text = "M-";
            this.MEMSUB.UseVisualStyleBackColor = false;
            this.MEMSUB.Click += new System.EventHandler(this.MEMSUB_Click);
            // 
            // MEMREAD
            // 
            this.MEMREAD.BackColor = System.Drawing.Color.DarkGray;
            this.MEMREAD.FlatAppearance.BorderSize = 0;
            this.MEMREAD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MEMREAD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.MEMREAD.Location = new System.Drawing.Point(175, 87);
            this.MEMREAD.Name = "MEMREAD";
            this.MEMREAD.Size = new System.Drawing.Size(56, 31);
            this.MEMREAD.TabIndex = 20;
            this.MEMREAD.Text = "MR";
            this.MEMREAD.UseVisualStyleBackColor = false;
            this.MEMREAD.Click += new System.EventHandler(this.MEMREAD_Click);
            // 
            // SQRT
            // 
            this.SQRT.BackColor = System.Drawing.Color.DarkGray;
            this.SQRT.FlatAppearance.BorderSize = 0;
            this.SQRT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SQRT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.SQRT.Location = new System.Drawing.Point(231, 87);
            this.SQRT.Name = "SQRT";
            this.SQRT.Size = new System.Drawing.Size(56, 31);
            this.SQRT.TabIndex = 22;
            this.SQRT.Text = "√x";
            this.SQRT.UseVisualStyleBackColor = false;
            this.SQRT.Click += new System.EventHandler(this.SQRT_Click);
            // 
            // CL
            // 
            this.CL.BackColor = System.Drawing.Color.Gray;
            this.CL.FlatAppearance.BorderSize = 0;
            this.CL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CL.Location = new System.Drawing.Point(231, 174);
            this.CL.Name = "CL";
            this.CL.Size = new System.Drawing.Size(56, 170);
            this.CL.TabIndex = 23;
            this.CL.Text = "Clear";
            this.CL.UseVisualStyleBackColor = false;
            this.CL.Click += new System.EventHandler(this.CL_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(294, 351);
            this.Controls.Add(this.CL);
            this.Controls.Add(this.SQRT);
            this.Controls.Add(this.MEMREAD);
            this.Controls.Add(this.MEMSUB);
            this.Controls.Add(this.EQ);
            this.Controls.Add(this.POW);
            this.Controls.Add(this.MEMADD);
            this.Controls.Add(this.MEMC);
            this.Controls.Add(this.ADD);
            this.Controls.Add(this.SUB);
            this.Controls.Add(this.MULTI);
            this.Controls.Add(this.DIVD);
            this.Controls.Add(this.NUM0);
            this.Controls.Add(this.NUM9);
            this.Controls.Add(this.NUM8);
            this.Controls.Add(this.NUM7);
            this.Controls.Add(this.NUM6);
            this.Controls.Add(this.NUM5);
            this.Controls.Add(this.NUM4);
            this.Controls.Add(this.NUM3);
            this.Controls.Add(this.NUM2);
            this.Controls.Add(this.NUM1);
            this.Controls.Add(this.Screen);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Screen;
        private System.Windows.Forms.Button NUM1;
        private System.Windows.Forms.Button NUM2;
        private System.Windows.Forms.Button NUM3;
        private System.Windows.Forms.Button NUM4;
        private System.Windows.Forms.Button NUM5;
        private System.Windows.Forms.Button NUM6;
        private System.Windows.Forms.Button NUM7;
        private System.Windows.Forms.Button NUM8;
        private System.Windows.Forms.Button NUM9;
        private System.Windows.Forms.Button NUM0;
        private System.Windows.Forms.Button DIVD;
        private System.Windows.Forms.Button MULTI;
        private System.Windows.Forms.Button SUB;
        private System.Windows.Forms.Button ADD;
        private System.Windows.Forms.Button MEMC;
        private System.Windows.Forms.Button MEMADD;
        private System.Windows.Forms.Button POW;
        private System.Windows.Forms.Button EQ;
        private System.Windows.Forms.Button MEMSUB;
        private System.Windows.Forms.Button MEMREAD;
        private System.Windows.Forms.Button SQRT;
        private System.Windows.Forms.Button CL;
    }
}

